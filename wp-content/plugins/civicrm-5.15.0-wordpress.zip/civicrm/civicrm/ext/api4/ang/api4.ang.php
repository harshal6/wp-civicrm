<?php
// Autoloader data for Api4 angular module.
return [
  'js' => [
    'ang/api4.js',
    'ang/api4/*.js',
    'ang/api4/*/*.js',
  ],
  'css' => [],
  'partials' => [],
  'requires' => [],
];
