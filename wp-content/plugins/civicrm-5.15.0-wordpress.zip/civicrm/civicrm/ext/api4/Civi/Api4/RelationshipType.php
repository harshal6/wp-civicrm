<?php

namespace Civi\Api4;

/**
 * RelationshipType entity.
 *
 * @package Civi\Api4
 */
class RelationshipType extends Generic\DAOEntity {

}
