<?php

namespace Civi\Api4;

/**
 * Website entity.
 *
 * @package Civi\Api4
 */
class Website extends Generic\DAOEntity {

}
