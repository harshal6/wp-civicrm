<?php

namespace Civi\Api4\Action\CustomValue;

/**
 * @inheritDoc
 */
class Create extends \Civi\Api4\Generic\DAOCreateAction {
  use \Civi\Api4\Generic\Traits\CustomValueActionTrait;

}
