<?php

namespace Civi\Api4;

/**
 * UFJoin entity - links profiles to the components/extensions they are used for.
 *
 * @package Civi\Api4
 */
class UFJoin extends Generic\DAOEntity {

}
