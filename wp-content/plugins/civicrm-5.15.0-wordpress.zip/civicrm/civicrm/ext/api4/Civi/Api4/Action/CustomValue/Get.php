<?php

namespace Civi\Api4\Action\CustomValue;

/**
 * Get fields for a custom group.
 */
class Get extends \Civi\Api4\Generic\DAOGetAction {
  use \Civi\Api4\Generic\Traits\CustomValueActionTrait;

}
