<?php

namespace Civi\Api4;

/**
 * Group entity.
 *
 * @package Civi\Api4
 */
class Group extends Generic\DAOEntity {

}
