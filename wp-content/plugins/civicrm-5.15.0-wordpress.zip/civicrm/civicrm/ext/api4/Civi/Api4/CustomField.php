<?php

namespace Civi\Api4;

/**
 * CustomField entity.
 *
 * @package Civi\Api4
 */
class CustomField extends Generic\DAOEntity {

}
