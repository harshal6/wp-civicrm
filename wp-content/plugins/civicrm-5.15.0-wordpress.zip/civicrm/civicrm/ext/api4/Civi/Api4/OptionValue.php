<?php

namespace Civi\Api4;

/**
 * OptionValue entity.
 *
 * @package Civi\Api4
 */
class OptionValue extends Generic\DAOEntity {

}
