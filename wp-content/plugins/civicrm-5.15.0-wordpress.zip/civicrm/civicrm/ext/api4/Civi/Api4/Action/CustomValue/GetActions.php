<?php

namespace Civi\Api4\Action\CustomValue;

/**
 * @inheritDoc
 */
class GetActions extends \Civi\Api4\Action\GetActions {
  use \Civi\Api4\Generic\Traits\CustomValueActionTrait;

}
