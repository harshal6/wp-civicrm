<?php

namespace Civi\Test\Api4\Mock;


/**
 * Grandchild class
 *
 * This is an extended description.
 *
 * There is a line break in this description.
 *
 * @inheritdoc
 */
class MockV4ReflectionGrandchild extends MockV4ReflectionChild {

}
